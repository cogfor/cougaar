/*
 *
 * Copyright 2007 by BBN Technologies Corporation
 *
 */

package org.cougaar.core.qos.coordinations.sweep.bundled;

import java.io.Serializable;

enum ConnectionSetup implements Serializable {
    LEADER,
    FOLLOWER
}