package org.cougaar.core.qos.frame.visualizer.shapes;

/**
 * Created by IntelliJ IDEA.
 * User: mwalczak
 * Date: May 3, 2005
 * Time: 12:07:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class Rectangle extends java.awt.geom.Rectangle2D.Double {
    /**
    * 
    */
   private static final long serialVersionUID = 1L;
   public Rectangle() {
        super();
    }
    public Rectangle(double x, double y, double w, double h) {
        super(x,y,w,h);
    }
}
