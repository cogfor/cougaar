package org.cougaar.test.knode.experiment.bette;

public interface Quitable {
   public void quit();
}
